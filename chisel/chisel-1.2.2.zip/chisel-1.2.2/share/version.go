package chshare

//Chisel protocol version. When backwards
//incompatible changes are made, this will
//be incremented to signify a protocol
//mismatch.
const ProtocolVersion = "chisel-v2"

var BuildVersion = "0.0.0-src"
